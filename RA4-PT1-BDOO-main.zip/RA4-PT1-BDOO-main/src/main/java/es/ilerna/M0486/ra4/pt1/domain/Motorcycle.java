
package es.ilerna.M0486.ra4.pt1.domain;

public class Motorcycle extends Vehicle {

	private boolean hasSidecar;
	
	public Motorcycle() {
		super();
	}
	
	public Motorcycle(String brand, int year, float price, boolean hasSidecar) {
		super(brand, year, price);
		this.hasSidecar = hasSidecar;
	}
	
	public boolean isHasSidecar() {
		return hasSidecar;
	}

	public void setHasSidecar(boolean hasSidecar) {
		this.hasSidecar = hasSidecar;
	}

	@Override
	public String toString() {
		return "Motorcycle{" +
				super.toString() +
				", hasSidecar=" + hasSidecar +
				'}';
	}
}
