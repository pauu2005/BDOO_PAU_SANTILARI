package es.ilerna.M0486.ra4.pt1.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "car")
public class Car extends Vehicle {

	private int doors;
	private int seats;
	
	public Car() {
		super();
	}
	
	public Car(String brand, int year, float price, int doors, int seats) {
		super(brand, year, price);
		this.doors = doors;
		this.seats = seats;
	}
	
	public int getDoors() {
		return doors;
	}
	public void setDoors(int doors) {
		this.doors = doors;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	
	
}
