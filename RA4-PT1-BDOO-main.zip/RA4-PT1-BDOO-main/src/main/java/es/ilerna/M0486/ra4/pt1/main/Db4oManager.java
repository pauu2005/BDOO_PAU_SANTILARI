package es.ilerna.M0486.ra4.pt1.main;

import java.io.File;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.config.EmbeddedConfiguration;

public class Db4oManager {

	public static final String DB_FILE = "ra4.db4o";
	
	public static ObjectContainer open() {
		EmbeddedConfiguration config = Db4oEmbedded.newConfiguration();
		
		config.common().activationDepth(10);
		config.common().updateDepth(10);
		
		return Db4oEmbedded.openFile(config, DB_FILE);
	}
	
	public static void deleteDbFile() {
		File f = new File(DB_FILE);
		if (f.exists()) f.delete();
	}
}
