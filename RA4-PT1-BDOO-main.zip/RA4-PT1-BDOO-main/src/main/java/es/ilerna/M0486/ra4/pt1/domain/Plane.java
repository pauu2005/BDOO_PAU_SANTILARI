
package es.ilerna.M0486.ra4.pt1.domain;

public class Plane extends Vehicle {

	private int tailNumber;
	private boolean autopilot;
	
	public Plane() {
		super();
	}
	
	public Plane(String brand, int year, float price, int tailNumber, boolean autopilot) {
		super(brand, year, price);
		this.tailNumber = tailNumber;
		this.autopilot = autopilot;
	}
	
	public int getTailNumber() {
		return tailNumber;
	}
	
	public void setTailNumber(Integer tailNumber) {
		this.tailNumber = tailNumber;
	}
	
	public boolean isAutopilot() {
		return autopilot;
	}
	
	public void setAutopilot(boolean autopilot) {
		this.autopilot = autopilot;
	}

	@Override
	public String toString() {
		return "Plane{" +
				super.toString() +
				", tailNumber=" + tailNumber +
				", autopilot=" + autopilot +
				'}';
	}
}
