package es.ilerna.M0486.ra4.pt1.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("STUDENT")
public class Student extends Person {

	private String studentCode;
	
	public Student() {
		super();
	}

	public Student(String name, String surname, Integer phoneNumber, String studentCode) {
		super(name, surname, phoneNumber);
		this.studentCode = studentCode;
	}

	public String getStudentCode() {
		return studentCode;
	}

	public void setStudentCode(String studentCode) {
		this.studentCode = studentCode;
	}
}