package es.ilerna.M0486.ra4.pt1.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Query;

import es.ilerna.M0486.ra4.pt1.domain.Car;
import es.ilerna.M0486.ra4.pt1.domain.Motorcycle;
import es.ilerna.M0486.ra4.pt1.domain.Person;
import es.ilerna.M0486.ra4.pt1.domain.Plane;
import es.ilerna.M0486.ra4.pt1.domain.Student;
import es.ilerna.M0486.ra4.pt1.domain.Teacher;
import es.ilerna.M0486.ra4.pt1.domain.Vehicle;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int opcio;

		do {
			System.out.println("\n===== MENÚ PRINCIPAL =====");
			System.out.println("1) Fase 1: Crear dades de prova");
			System.out.println("2) Fase 2: Treure vehicles de persones");
			System.out.println("3) Fase 3: Actualitzar un vehicle");
			System.out.println("4) Fase 4: Carregar i visualitzar dades (db4o)");
			System.out.println("0) Sortir");
			System.out.print("Escull una opció: ");

			opcio = sc.nextInt();
			sc.nextLine();

			switch (opcio) {
				case 1:
					phase1();
					break;
				case 2:
					phase2();
					break;
				case 3:
					phase3();
					break;
				case 4:
					phase4();
					break;
				case 0:
					System.out.println("Fins aviat!");
					break;
				default:
					System.out.println("Opció incorrecta.");
			}

		} while (opcio != 0);

		sc.close();
	}
	
	private static void phase1() {
		// TODO: Implementar phase1
	}
	
	private static void phase2() {
		// TODO: Implementar phase2
	}

	private static void phase3() {

		ObjectContainer db = null;
		List<Vehicle> vehicles = new ArrayList<>();
		
		try {
			db = Db4oManager.open();
			
			vehicles = loadAll(db, Vehicle.class);
			
			if (vehicles.isEmpty()) {
				System.out.println("Primer has de fer la Fase 1.");
				return;
			}

			Vehicle firstVehicle = vehicles.get(0);

			firstVehicle.setBrand("Seat");
			firstVehicle.setYear(2022);
			firstVehicle.setPrice(19999);
			
			db.store(firstVehicle);
			db.commit();
			
			System.out.println("Vehicle actualitzat: " + firstVehicle);
		} catch (Exception ex) {
			if (db != null) db.rollback();
			ex.printStackTrace();
		} finally {
			if (db != null) db.close();
		}
	}
	
	private static void phase4() {
		ObjectContainer db = null;
		
		try {
			db = Db4oManager.open();
			
			List<Person> persons = loadAll(db, Person.class);
			List<Vehicle> allVehicles = loadAll(db, Vehicle.class);
			
			if (persons.isEmpty() && allVehicles.isEmpty()) {
				System.out.println("No hi ha dades a la base de dades. Executa primer la Fase 1.");
				return;
			}
			
			System.out.println("\n===== DADES DE LA BASE DE DADES (db4o) =====");
			
			System.out.println("\n--- PERSONES (" + persons.size() + ") ---");
			for (Person p : persons) {
				System.out.println(p.toString());
				
				if (p.getVehicles() != null && !p.getVehicles().isEmpty()) {
					System.out.println("  Vehicles:");
					for (Vehicle v : p.getVehicles()) {
						System.out.println("   - " + v.toString());
					}
				} else {
					System.out.println("  Vehicles: (cap)");
				}
			}
			
			System.out.println("\n--- VEHICLES TOTALS (" + allVehicles.size() + ") ---");
			for (Vehicle v : allVehicles) {
				System.out.println(v.toString());
			}
		
		} catch (Exception ex) {
			if (db != null) db.rollback();
			ex.printStackTrace();
		} finally {
			if (db != null) db.close();
		}
	}
	
	private static <T> List<T> loadAll(ObjectContainer db, Class<T> clazz) {
		Query q = db.query();
		q.constrain(clazz);
		ObjectSet<T> set = q.execute();
		
		List<T> list = new ArrayList<>();
		while (set.hasNext()) list.add(set.next());
		return list;
	}
}
