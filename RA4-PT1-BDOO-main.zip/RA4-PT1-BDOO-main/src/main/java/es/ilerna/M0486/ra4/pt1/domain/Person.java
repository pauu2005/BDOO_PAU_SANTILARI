package es.ilerna.M0486.ra4.pt1.domain;


import java.util.ArrayList;
import java.util.List;

public abstract class Person {

	private String name;
	private String surname;
	private Integer phoneNumber;
	private List<Vehicle> vehicles = new ArrayList<>();
	
	public Person() {
		super();
	}

	public Person(String name, String surname, Integer phoneNumber) {
		super();
		this.name = name;
		this.surname = surname;
		this.phoneNumber = phoneNumber;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public Integer getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
	
	public void addVehicle(Vehicle vehicle) {
		this.vehicles.add(vehicle);
	}

	public void removeVehicle(Vehicle vehicle) {
		this.vehicles.remove(vehicle);
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", surname=" + surname + ", phoneNumber=" + phoneNumber
				+ ", vehicles=" + vehicles + "]";
	}
}